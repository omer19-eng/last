"use client";

import Image from "next/image";
import Link from "next/link";
import { X, MapPin } from "lucide-react";

export default function CardPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-stone-900 p-4 relative">
      
      {/* Close Button */}
      <Link 
        href="/" 
        className="absolute top-6 right-6 text-white/60 hover:text-white transition z-20 flex items-center gap-2 bg-black/30 p-2 rounded-full backdrop-blur-sm"
      >
        <span className="text-sm uppercase tracking-wider pl-2 text-white">Close</span> 
        <X size={24} className="text-white" />
      </Link>

      {/* Invitation Image */}
      <div className="relative h-auto w-full max-w-2xl shadow-2xl rounded-lg overflow-hidden border-4 border-stone-800/50">
        <Image
          src="/wedding-card.jpg"
          alt="Wedding Invitation Card"
          width={1080} 
          height={1920} 
          className="w-full h-auto object-contain"
          priority
        />
      </div>

      {/* Location Section - Centered beneath the image */}
      <div className="mt-8 flex flex-col items-center text-center">
        <Link 
          href="https://maps.app.goo.gl/2VqKozLmqJHahhk5A" 
          target="_blank"
          className="px-8 py-3 bg-[#d4af37] text-white text-xs tracking-[0.2em] uppercase rounded-full shadow-lg hover:bg-stone-700 transition-all duration-500 flex items-center gap-2"
        >
          <MapPin size={16} />
          View Venue on Maps
        </Link>
        
        <p className="mt-4 text-stone-400 text-[10px] tracking-[0.3em] uppercase">
          Milano Event Complex, Garden Town, Lahore (30 Jan 26)
        </p>
      </div>

      <p className="text-stone-500 mt-6 text-[10px] uppercase tracking-widest font-sans">
        You can save this image or take a screenshot for reference.
      </p>
    </main>
  );
}