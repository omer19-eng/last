// src/app/layout.js
import { Cinzel_Decorative, Pinyon_Script, Montserrat } from "next/font/google";
import "./globals.css";

// Font for main elegant headings
const cinzel = Cinzel_Decorative({ 
  subsets: ["latin"], 
  weight: ["400", "700"],
  variable: '--font-cinzel'
});

// Font for script/cursive names
const pinyon = Pinyon_Script({ 
  subsets: ["latin"], 
  weight: ["400"],
  variable: '--font-pinyon'
});

// Font for readable body text
const montserrat = Montserrat({
  subsets: ["latin"],
  variable: '--font-montserrat'
})

export const metadata = {
  title: "Faria & Usama's Wedding",
  description: "You are invited to celebrate with us.",
};
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={`${cinzel.variable} ${pinyon.variable} ${montserrat.variable} bg-cream-50 text-stone-800`}>
        {children}
      </body>
    </html>
  );
}