"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState, useEffect } from 'react';

function InvitationContent() {
  const searchParams = useSearchParams();
  const guestName = searchParams.get('name') || "Honored Guest";

  // State for the countdown
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, mins: 0, secs: 0 });

  useEffect(() => {
    // Setting the target date: Jan 30, 2026
    const targetDate = new Date("2026-01-30T20:00:00"); 

    const timer = setInterval(() => {
      const now = new Date();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          mins: Math.floor((difference / 1000 / 60) % 60),
          secs: Math.floor((difference / 1000) % 60),
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-[#fdfcf8] animate-fade font-montserrat text-center">
  
    <div className="max-w-xl w-full z-10 border-2 border-[#d4af37]/30 p-8 md:p-12 rounded-sm shadow-2xl bg-white relative flex flex-col items-center">
      
      {/* Corner Decorations */}
      <div className="absolute top-2 left-2 w-12 h-12 border-t-2 border-l-2 border-[#d4af37]" />
      <div className="absolute bottom-2 right-2 w-12 h-12 border-b-2 border-r-2 border-[#d4af37]" />
  
      <p className="text-[#8b7355] uppercase tracking-[0.3em] text-[10px] mb-8 italic">
        In the name of Allah, the Most Beneficent
      </p>
      
      <h1 className="font-cinzel text-2xl md:text-4xl mb-4 text-stone-800 tracking-tight">
        Dear <span className="text-[#b8860b] block mt-2 italic font-pinyon text-5xl normal-case">{guestName},</span>
      </h1>
  
      <p className="text-sm md:text-base mb-6 text-stone-500 font-light tracking-wide uppercase">
        You are warmly invited to celebrate the <br/> wedding ceremony of Beloved <br/> <span className="font-bold text-stone-700">Daughter Of Mr. & Mrs. Ch. Awais</span>
      </p>
      
      <div className="my-6">
         <h2 className="font-pinyon text-6xl md:text-7xl text-stone-800 leading-tight">Usama Imran</h2>
         <div className="flex items-center justify-center gap-4 my-2">
           <div className="h-[1px] w-12 bg-[#d4af37]/50"></div>
           <span className="font-pinyon text-4xl text-[#b8860b]">&</span>
           <div className="h-[1px] w-12 bg-[#d4af37]/50"></div>
         </div>
         <h2 className="font-pinyon text-6xl md:text-7xl text-stone-800 leading-tight">Faria Awais</h2>
      </div>

      {/* --- NEW COUNTDOWN SECTION --- */}
      <div className="flex gap-4 mb-10 mt-4">
        {[
          { label: "Days", value: timeLeft.days },
          { label: "Hrs", value: timeLeft.hours },
          { label: "Mins", value: timeLeft.mins },
          { label: "Secs", value: timeLeft.secs }
        ].map((item, index) => (
          <div key={index} className="flex flex-col items-center">
            <span className="text-xl font-cinzel text-stone-800">{item.value}</span>
            <span className="text-[9px] uppercase tracking-widest text-[#d4af37] font-bold">{item.label}</span>
          </div>
        ))}
      </div>
  
      <p className="mb-10 text-stone-500 italic font-light text-sm">
        "And among His signs is that He created for you mates <br/> 
        from among yourselves..."
      </p>
  
      <Link 
        href="/card" 
        target="_blank"
        className="inline-block border border-stone-800 px-8 py-3 text-sm tracking-[0.2em] uppercase hover:bg-stone-800 hover:text-white transition-all duration-500 ease-in-out"
      >
        View Invitation Card
      </Link>
    </div>
  </main>
  );
}

export default function Home() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <InvitationContent />
    </Suspense>
  );
}